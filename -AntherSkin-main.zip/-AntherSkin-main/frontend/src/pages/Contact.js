import React from 'react';

const Contact = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Contact Us</h1>
      <p>Email: support@antherskin.com</p>
      <p>Instagram: @antherskin</p>
    </div>
  );
};

export default Contact;
