import React from 'react';

const About = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>About AntherSkin</h1>
      <p>We are passionate about skincare with gentle, pastel vibes.</p>
    </div>
  );
};

export default About;
