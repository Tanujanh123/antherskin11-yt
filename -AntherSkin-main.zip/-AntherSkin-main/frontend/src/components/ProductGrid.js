import React from 'react';

const ProductGrid = () => {
  return (
    <section style={{ padding: '2rem', backgroundColor: '#f3f4f6' }}>
      <h2>Our Products</h2>
      <p>(Product display will come here)</p>
    </section>
  );
};

export default ProductGrid;
