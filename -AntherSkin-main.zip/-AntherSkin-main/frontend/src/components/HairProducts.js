// src/components/HairProducts.js
import React from 'react';

const HairProducts = () => {
    return (
        <div>
            <h2>Hair Products</h2>
            <p>Explore our range of hair care products!</p>
            {/* Add details about hair products here */}
        </div>
    );
};

export default HairProducts;