import React from 'react';
import '../App.css'; // Make sure styles are loaded

const Intro = () => {
  return (
    <div className="intro">
      <h1>AntherSkin</h1>
    </div>
  );
};

export default Intro;
